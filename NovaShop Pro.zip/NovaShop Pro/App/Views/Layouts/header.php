<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>NovaShop</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>
    <header class="navbar">
    <div class="logo">NovaShop</div>
    <nav>
        <a href="/">Accueil</a>
        <a href="/products">Produits</a>
        <a href="/cart">Panier</a>
        <a href="/login">Connexion</a>
    </nav>
    </header>

    <main class="container">
