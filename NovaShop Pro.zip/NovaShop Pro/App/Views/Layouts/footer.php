    </main>

    <footer class="footer">
    <p>© <?= date('Y') ?> NovaShop — Tous droits réservés</p>
    </footer>

</body>
</html>
