<div class="admin-products">
    <h2>📦 Gestion des produits</h2>
    
    <button onclick="alert('Ajouter un nouveau produit')">➕ Ajouter un produit</button>
    
    <table border="1" cellpadding="10">
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Prix</th>
            <th>Stock</th>
            <th>Actions</th>
        </tr>
        <tr>
            <td>1</td>
            <td>Exemple Produit</td>
            <td>29.99€</td>
            <td>10</td>
            <td>
                <button>Éditer</button>
                <button>Supprimer</button>
            </td>
        </tr>
    </table>
    
    <p><a href="/admin/dashboard">← Retour au dashboard</a></p>
</div>
