<div class="admin-orders">
    <h2>📋 Gestion des commandes</h2>
    
    <table border="1" cellpadding="10">
        <tr>
            <th>ID</th>
            <th>Utilisateur</th>
            <th>Total</th>
            <th>Statut</th>
            <th>Date</th>
            <th>Actions</th>
        </tr>
        <tr>
            <td>1</td>
            <td>User Example</td>
            <td>99.99€</td>
            <td>pending</td>
            <td>2024-01-01</td>
            <td>
                <button>Voir détails</button>
                <button>Mettre à jour</button>
            </td>
        </tr>
    </table>
    
    <p><a href="/admin/dashboard">← Retour au dashboard</a></p>
</div>
