<div class="admin-users">
    <h2>👥 Gestion des utilisateurs</h2>
    
    <table border="1" cellpadding="10">
        <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Email</th>
            <th>Rôle</th>
            <th>Actions</th>
        </tr>
        <tr>
            <td>1</td>
            <td>Admin User</td>
            <td>admin@test.com</td>
            <td>admin</td>
            <td>
                <button>Éditer</button>
                <button>Supprimer</button>
            </td>
        </tr>
    </table>
    
    <p><a href="/admin/dashboard">← Retour au dashboard</a></p>
</div>
