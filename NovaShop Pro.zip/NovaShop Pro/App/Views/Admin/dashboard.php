<div class="admin">
    <h2>👨‍💼 Dashboard Admin</h2>
    <p>Bienvenue dans l'espace administrateur.</p>
    <ul>
        <li><a href="/admin/users">Gérer les utilisateurs</a></li>
        <li><a href="/admin/products">Gérer les produits</a></li>
        <li><a href="/admin/orders">Voir les commandes</a></li>
    </ul>
</div>
