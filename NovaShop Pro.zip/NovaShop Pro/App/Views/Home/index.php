<h1 class="title">Bienvenue sur NovaShop</h1>
<p class="subtitle">Le e-commerce nouvelle génération.</p>

<div class="hero">
    <p>🔥 Architecture MVC maison</p>
    <p>🛒 Panier intelligent</p>
    <p>🔐 Authentification sécurisée</p>
</div>
