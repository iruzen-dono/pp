<div class="order-create">
    <h2>✅ Créer une commande</h2>
    
    <p>Veuillez valider votre panier pour confirmer votre commande.</p>
    
    <form method="POST">
        <button type="submit">Confirmer la commande</button>
    </form>
    
    <p><a href="/cart">← Retour au panier</a></p>
</div>
