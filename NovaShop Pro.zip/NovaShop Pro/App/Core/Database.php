<?php
namespace App\Core;

// Ce fichier est conservé pour la compatibilité.
// Utiliser App\Config\Database à la place.
require_once __DIR__ . '/../config/Database.php';
