<?php

session_start();

require_once __DIR__ . '/../App/Core/App.php';

use App\Core\App;

$app = new App();
$app->run();
